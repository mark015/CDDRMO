<?php
require_once'include/conn.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$id = $_GET['id'];
// sql to delete a record
$sql = "DELETE FROM tbl_brgy WHERE id=$id";

if ($conn->query($sql) === TRUE) {
  echo "
    <script>
        alert('Successfully Deleted');
        window.location.href='add_brgy.php';
    </script>";
} else {
  echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>