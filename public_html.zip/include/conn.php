<?php
$servername = "localhost";
$username = "u722023368_cdrrmo";
$password = "myCode22";
$dbname = "u722023368_cdrrmo_SC";
?>