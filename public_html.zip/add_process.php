<?php
require_once'include/conn.php';
$conn = new mysqli($servername, $username, $password, $dbname);
if ( isset( $_POST['submit'] ) ) {
    date_default_timezone_set("Asia/Manila");
    $date = date('Y-m-d h:i:sa');
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $type_inc = $_POST['type_inc'];
    $cause_inc = $_POST['c_inc'];
    $add_inc = $_POST['add_inc'];    
    
    
    
    
    $img = $_FILES['img']['name'];
    $total = count($_FILES['img']['name']);
    
    // Loop through each file
    for($i=0; $i<$total; $i++) {
        $im .= $img[$i] . "/";
      //Get the temp file path
      $tmpFilePath = $_FILES['img']['tmp_name'][$i];
    
      //Make sure we have a filepath
      if ($tmpFilePath != ""){
        //Setup our new file path
        $newFilePath = "dist/img/" . $_FILES['img']['name'][$i];
    
        //Upload the file into the temp dir
        if(move_uploaded_file($tmpFilePath, $newFilePath)) {
          //Handle other code here
          
    
        }
      }
    }
        
        $sql = "SELECT * FROM tbl_brgy WHERE brgy='$add_inc'";
        $qry = mysqli_query($conn,$sql);
        $brgy_data = mysqli_fetch_array($qry);
        $brgy_id=$brgy_data['id'];
        
        
        $query = "SELECT * FROM `tbl_candidates` WHERE `lrn_no` = '$lrn_no'";
        $result_object = mysqli_query($conn, $query);
        $data = mysqli_fetch_assoc($result_object);
        $query1 = "INSERT INTO `incident`(`id`, `brgy_id`, `inc_id`, `fname`, `mname`, `lname` , `gender`, `age`, `address`, `cause_inc`, `date`, `img`) VALUES ('','$brgy_id', '$type_inc', '$fname', '$mname', '$lname' , '$gender', '$age', '$address', '$cause_inc', '$date', '$im' )";
                $result = mysqli_query($conn, $query1);
                if ($result == TRUE) {
                    echo "
                        <script>
                            alert('Succesfully Save!!');
                            window.location.href='user.php';
                        </script>";
                } else { 
                echo "
                    <script>
                        alert('Something Went Wrong!!');
                        window.location.href='user.php';
                    </script>";
            }
        
    
}

if(isset($_POST['add_brgy'])){
    $brgy = $_POST['brgy'];
    
    $sql = "SELECT * FROM tbl_brgy WHERE brgy='$brgy'";
    $qry = mysqli_query($conn,$sql);
    $brgy_data = mysqli_fetch_array($qry);
    if($brgy_data['brgy'] == TRUE){
        echo "
                    <script>
                        alert('Existed Barangay!!');
                        window.location.href='add_brgy.php';
                    </script>";
    }else{
         $query1 = "INSERT INTO `tbl_brgy`(`id`, `brgy`) VALUES ('', '$brgy' )";
                $result = mysqli_query($conn, $query1);
                if ($result == TRUE) {
                    echo "
                        <script>
                            alert('Succesfully Save!!');
                            window.location.href='add_brgy.php';
                        </script>";
                } else { 
                echo "
                    <script>
                        alert('Something Went Wrong!!');
                        window.location.href='user.php';
                    </script>";
            }
    }
        
    
}


if(isset($_POST['add_inc_type'])){
    $inc_type = $_POST['inc_type'];
    
    $sql = "SELECT * FROM incident_type WHERE inc_type='$inc_type'";
    $qry = mysqli_query($conn,$sql);
    $inc_type_data = mysqli_fetch_array($qry);
    if($inc_type_data['brgy'] == TRUE){
        echo "
                    <script>
                        alert('Existed Barangay!!');
                        window.location.href='add_brgy.php';
                    </script>";
    }else{
         $query1 = "INSERT INTO `incident_type`(`id`, `inc_type`) VALUES ('', '$inc_type' )";
                $result = mysqli_query($conn, $query1);
                if ($result == TRUE) {
                    echo "
                        <script>
                            alert('Succesfully Save!!');
                            window.location.href='add_inc_type.php';
                        </script>";
                } else { 
                echo "
                    <script>
                        alert('Something Went Wrong!!');
                        window.location.href='user.php';
                    </script>";
            }
    }
        
    
}

if(isset($_POST['add_user'])){
    $brgy_id=$_GET['id'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $role = $_POST['role'];
    $hash_pass = hash(sha256, '$pass');

         $query1 = "INSERT INTO `user`(`id`, `uname`, `pass`, `pos`, `brgy_id` ) VALUES ('', '$uname', '$hash_pass', '$role', '$brgy_id')";
                $result = mysqli_query($conn, $query1);
                if ($result == TRUE) {
                    echo "
                        <script>
                            alert('Succesfully Save!!');
                            window.location.href='view_brgy.php?id=$brgy_id';
                        </script>";
                } else { 
                echo "
                    <script>
                        alert('Something Went Wrong!!');
                        window.location.href='view_brgy.php?id=$brgy_id';
                    </script>";
            }
  
    
}





?>